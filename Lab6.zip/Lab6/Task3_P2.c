#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define SHM_SIZE 10

void Error(const char* msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(void)
{
    // create shm
    int shmid = shmget(123, SHM_SIZE, IPC_CREAT | 0666);
    if(shmid < 0)
    {
        Error("shmget");
    }
    // get ptr to shm
    char* shm = shmat(shmid, NULL, 0);
    if(shm == (char*)-1)
    {
        Error("shmat");
    }

    char buf[SHM_SIZE + 1] = {}; // +1 in case shm has no null terminator
    // read number
    strncpy(buf, shm, SHM_SIZE);
    int num = atoi(buf);
    printf("Number received from P1: %d\n", num);
    // put ready in shm
    strncpy(shm, "Ready", SHM_SIZE);
    
    for(int i = 1; i <= 10; i++)
    {
        // wait for * to be put in memory
        while(strncmp(shm, "*", SHM_SIZE) != 0)
        {
            sleep(1);
        }
        printf("* received from P1\n");
        // put result in memory
        int calc_res = num * i;
        sprintf(shm, "%d", calc_res);
    }

    return 0;
}