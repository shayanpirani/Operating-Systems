#include <stdio.h>
#include <sys/shm.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define SHM_SIZE sizeof(long long)

void Error(const char* msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        printf("Usage: ./Task4_C n\n");
        exit(EXIT_FAILURE);
    }
    // get shm of A
    int shmid_a = shmget('A', SHM_SIZE, 0666);
    if(shmid_a < 0)
    {
        Error("shmget a");
    }
    char* shm_a = shmat(shmid_a, NULL, 0);
    if(shm_a == (char*)-1)
    {
        Error("shmat b");
    }

    // get shm of B
    int shmid_b = shmget('B', SHM_SIZE, 0666);
    if(shmid_a < 0)
    {
        Error("shmget b");
    }
    char* shm_b = shmat(shmid_b, NULL, 0);
    if(shm_a == (char*)-1)
    {
        Error("shmat b");
    }

    long long n = atoi(argv[1]);
    for(int i = 0; i < n; i++)
    {
        // get the numbers from A and B
        long long num1, num2;
        memcpy(&num1, shm_a, SHM_SIZE);
        memcpy(&num2, shm_b, SHM_SIZE);
        // add nums
        long temp = num2;
        num2 = num1 + num2;
        num1 = temp;
        // print res
        printf("%lld ", num2);
        // store back
        memcpy(shm_a, &num1, SHM_SIZE);
        memcpy(shm_b, &num2, SHM_SIZE);
    }

    printf("\nSending exit msg to A and B\n");
    // send closing signal to A and B
    n = -1;
    memcpy(shm_a, &n, SHM_SIZE);
    memcpy(shm_b, &n, SHM_SIZE);

    shmdt(shm_a);
    shmdt(shm_b);
    return 0;
}