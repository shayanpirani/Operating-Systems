#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

int main(void)
{
    int fd = open("/tmp/Task2_fifo", O_RDONLY);
    if(fd == -1)
    {
        perror("open");
    }

    char buf[255] = {};
    while(read(fd, buf, sizeof(buf)) <= 0);
    close(fd);
    printf("Message received: %s\n", buf);
    
    return 0;
}