#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define SHM_SIZE 10

void Error(const char* msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        printf("Usage: ./Task3_P1 num\n");
        exit(EXIT_FAILURE);
    }
    // create shm
    int shmid = shmget(123, SHM_SIZE, IPC_CREAT | 0666);
    if(shmid < 0)
    {
        Error("shmget");
    }
    // get ptr to shm
    char* shm = shmat(shmid, NULL, 0);
    if(shm == (char*)-1)
    {
        Error("shmat");
    }
    // write number and wait for P2 to read
    strncpy(shm, argv[1], SHM_SIZE);
    printf("Number sent to P1: %s\n", argv[1]);
    while(strncmp(shm, "Ready", SHM_SIZE) != 0)
    {
        sleep(1);
    }
    // print ready
    printf("Message from P2: %s\n", shm);
    
    for(int i = 0; i < 10; i++)
    {
        // put * in memory
        strncpy(shm, "*", SHM_SIZE);
        // wait for other process to respond
        while(strncmp(shm, "*", SHM_SIZE) == 0)
        {
            sleep(1);
        }
        printf("Result from P1: %d\n", atoi(shm));
    }

    return 0;
}