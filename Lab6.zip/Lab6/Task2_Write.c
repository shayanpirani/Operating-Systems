#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

int main(void)
{
    int ret = mkfifo("/tmp/Task2_fifo", 0666);
    if(ret < 0)
    {
        perror("mkfifo");
    }

    int fd = open("/tmp/Task2_fifo", O_WRONLY);
    if(fd == -1)
    {
        perror("open");
    }
    char buf[] = "Hello there";
    write(fd, buf, sizeof(buf));
    close(fd);
    return 0;
}