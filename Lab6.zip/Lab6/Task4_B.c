#include <stdio.h>
#include <sys/shm.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define SHM_SIZE sizeof(num)

void Error(const char* msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(void)
{
    long long num = 1;
    int shmid = shmget('B', SHM_SIZE, IPC_CREAT | IPC_EXCL | 0666);
    if(shmid < 0)
    {
        Error("shmget");
    }
    char* shm = shmat(shmid, NULL, 0);
    if(shm == (char*)-1)
    {
        Error("shmat");
    }

    printf("Process started... will exit upon read -1 in shm\n");

    memcpy(shm, &num, SHM_SIZE);
    while(1)
    {
        memcpy(&num, shm, SHM_SIZE);
        if(num == -1)
            break;
        sleep(1);
    }

    printf("Exiting process\n");
    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}