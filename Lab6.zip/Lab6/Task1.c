#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void Proc(void* args)
{
    int write_pipe = *(int*)args;
    write(write_pipe, "Hello there", 11);
}

int CreateProcess(void* args)
{
    int PID = fork();
    if(PID < 0)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    else if(PID == 0)
    {
        Proc(args);
        exit(EXIT_SUCCESS);
    }
    return PID;
}

int main(void)
{
    int comm_pipe[2] = {};
    int ret = pipe(comm_pipe);
    int childID = CreateProcess(&comm_pipe[1]);

    char buf[256] = {};
    while(read(comm_pipe[0], buf, sizeof(buf) - 1) <= 0);
    printf("Message from child: %s\n", buf);

    return 0;
}